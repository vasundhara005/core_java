package com.cognizant.customers.xml;

import java.io.File;
import java.io.IOException;

import javax.xml.XMLConstants;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.xml.sax.SAXException;

public class XmlValidation {
	public static final String xmlFilePath = "C:\\Users\\2080580\\xmlfiles\\customer.xml";
	public static final String xmlFilePath1 = "C:\\Users\\2080580\\xmlfiles\\room.xml";
	public static final String xmlFilePath2 = "C:\\Users\\2080580\\xmlfiles\\booking.xml";
	public static final String SCHEMA_FILE = "C:\\Users\\2080580\\xmlfiles\\customer.xsd";
	public static final String SCHEMA_FILE1 = "C:\\Users\\2080580\\xmlfiles\\room.xsd";
	public static final String SCHEMA_FILE2 = "C:\\Users\\2080580\\xmlfiles\\booking.xsd";
	
	
	 @SuppressWarnings("unused")
	public static boolean validatecust() {
		
				 SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
	        try {
	            Schema schema = schemaFactory.newSchema(new File(SCHEMA_FILE));

	            Validator validator = schema.newValidator();
	            validator.validate(new StreamSource(new File(xmlFilePath)));
	            return true;
	        } catch (SAXException | IOException e) {
	            e.printStackTrace();
	            return false;
	        }
	    }
		public static boolean validateroom() {
			
			 SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
       try {
           Schema schema = schemaFactory.newSchema(new File(SCHEMA_FILE1));

           Validator validator = schema.newValidator();
           validator.validate(new StreamSource(new File(xmlFilePath1)));
           return true;
       } catch (SAXException | IOException e) {
           e.printStackTrace();
           return false;
       }
   }
    
		public static boolean validatebook() {
			
			 SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
       try {
           Schema schema = schemaFactory.newSchema(new File(SCHEMA_FILE2));

           Validator validator = schema.newValidator();
           validator.validate(new StreamSource(new File(xmlFilePath2)));
           return true;
       } catch (SAXException | IOException e) {
           e.printStackTrace();
           return false;
       }
   }
}
