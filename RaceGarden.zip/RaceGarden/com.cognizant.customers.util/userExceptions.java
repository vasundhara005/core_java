package com.cognizant.customer.util;

@SuppressWarnings("serial")
public class userExceptions  extends Exception{
	
	public userExceptions(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
